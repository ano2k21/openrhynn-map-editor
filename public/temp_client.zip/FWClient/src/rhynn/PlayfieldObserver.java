package rhynn;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marlowe
 */
public interface PlayfieldObserver {
    public void onCharacterRemoved(int id);
}
