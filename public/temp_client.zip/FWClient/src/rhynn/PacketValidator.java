package rhynn;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marlowe
 */
public class PacketValidator {
    
    public void initialize(long initValue) {}
    public void processGenericMessage(byte[] buffer) {}
    public void processAttackMessage(byte[] buffer) {}
    public void processMoveMessage(byte[] buffer) {}
}
