package rhynn;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import graphics.GFont;
import javax.microedition.lcdui.Graphics;

/**
 *
 * @author marlowe
 */
public class HighscoreEntry {
    int experience;
    String characterName;

    public void draw(Graphics g, GFont font) {
        
    }
}
