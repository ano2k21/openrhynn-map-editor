package rhynn;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marlowe
 */
public class ViewGeometry {
    int leftPosX;
    int topPosY;
    int viewX;
    int viewY;
    int viewWidth;
    int viewHeight;
}
