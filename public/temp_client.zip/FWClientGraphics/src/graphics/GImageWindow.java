/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graphics;

import javax.microedition.lcdui.Image;

/**
 *
 * @author marlowe
 */
public class GImageWindow extends GWindow {
    protected Image image = null;
    protected int clipOffsetX;
    protected int clipOffsetY;

}